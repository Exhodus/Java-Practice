package Hospital1;

public enum Gravetat {
    LLEU, MODERARA, GREU, CRITICA;
}
