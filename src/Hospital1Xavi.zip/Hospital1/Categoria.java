package Hospital1;

public enum Categoria {
    INTERN, RESIDEN, ESPECIALISTA;
}
