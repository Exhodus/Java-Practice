package Hospital1;

public enum Planta {
    NEONATAL, PEDIATRIA, GENERAL, GERIATRIA;
}
